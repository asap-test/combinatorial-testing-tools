const tcrtXML = require("../transaction_matrix/trans_create_xml");
const twrtXL = require("../transaction_matrix/trans_write_to_xl");
const icrtXML = require("../interface_matrix/inter_create_xml");
const iwrtXL = require("../interface_matrix/inter_write_to_xl");
const batFile = require("../utils/bat_file");
const readCsv = require("../utils/csvtojson");
const {
   crtDirectories,
   readConfig
} = require("../utils/create_directory");
const {
   crtPdf,
   apiCall,
   updtSchedule
} = require("../utils/utils");
const validate = require("../utils/validator");
const constants = require("../config/constants").constants;
const async = require("async");
const path = require("path");




/* Steps or Flow of the schedule execution
1) Inserting the Schedule ID in schedules.json
2) Inserting the Schedule status in DB (1-iniatied,2-processing,3-completed,4-errror)
3) Reading config sheet in XL
4) Updating the transaction and interface count in db
5) Transaction Matrix execution & interface if it is there
6) creating error report if error is there
7) updating the final status of the schedule
8) removing the schedule from schedules.json
*/


// Function to run the Transactions
exports.run = (runId) => {
   console.log(runId, " runID ");
   let errTxt = [];
   let engineId = constants.engineId;
   let apiKey = constants.apiKey;
   let host = constants.host;
   let hexFlag = constants.hexConversion;
   let statusUpdate = `/api/engine/schedule/statusUpdate`;
   let transIntrFUpdate = `/api/engine/schedule/transIntrfUpdate`;

   let headers = {
      engineId,
      apiKey
   }
   let allSuccess = true;
   let errFlag = false;

   async.waterfall([
      // Inserting the Schedule ID in schedules.json
      function insertSchedule(cb) {
         updtSchedule(runId, "insert")
            .then((resp) => {
               if (resp)
                  cb(null)
               else
                  cb(new Error("System Error"))
            })
            .catch(() => {
               cb(new Error("System Error"))
            })
      },

      // Inserting the Schedule status in DB (1-iniatied,2-processing,3-completed,4-errror)
      function statusUpdt(cb) {
         let url = `${host}${statusUpdate}`;
         apiCall(url, headers, {
               _id: runId,
               status: 2
            }, "post")
            .then((apiCallstatus) => {
               if (apiCallstatus)
                  cb(null)
               else
                  cb(new Error("System Error"))
            })
            .catch(() => {
               cb(new Error("System Error"))
            })
      },

      // Reading config sheet in XL
      function readConfigSheet(cb) {
         readConfig(runId)
            .then((pathJson) => {
               if (typeof (pathJson) === "object")
                  cb(null, pathJson)
               else if (typeof (pathJson) === "string") {
                  let configErr = pathJson;
                  errFlag = true;
                  cb(configErr, null)
               } else
                  cb(err, null)
            })
            .catch(() => {
               cb(new Error("System Error"))
            })
      },

      // creating the sub directories inside results folder
      function crtDirectory(pathJson, cb) {
         crtDirectories(pathJson)
            .then((counts) => {
               if (counts)
                  cb(null, pathJson, counts)
               else
                  cb(new Error("System Error"))
            })
            .catch(() => {
               cb(new Error("System Error"))
            })
      },

      // Updating the transaction count in db
      function updtTranCount(pathJson, counts, cb) {
         let {
            transactionCount,
            tranSheets
         } = counts;
         if (transactionCount > 0) {
            let url = `${host}${transIntrFUpdate}`;
            let transacData = tranSheets.map((element) => {
               let temp = {};
               temp.name = element;
               return temp;
            })
            apiCall(url, headers, {
                  _id: runId,
                  updateData: transacData,
                  type: "t-matrix"
               }, "post")
               .then((apiCallstatus) => {
                  if (apiCallstatus)
                     cb(null, pathJson, counts)
                  else
                     cb(new Error("System Error"))
               })
               .catch(() => {
                  cb(new Error("System Error"))
               })
         } else {
            cb(null, pathJson, counts)
         }
      },

      // Transaction Matrix execution 
      function executeTransaction(pathJson, counts, cb) {
         let {
            tranSheets,
            transactionCount
         } = counts;

         if (transactionCount > 0) {
            crtTransacMatrix(tranSheets, transactionCount, pathJson, hexFlag, errTxt)
               .then((tmatrixStatus) => {
                  if (tmatrixStatus)
                     cb(null, pathJson, counts)
                  else
                     cb(new Error("System Error"))
               })
               .catch(() => {
                  cb(new Error("System Error"))
               })
         } else {
            cb(null, pathJson, counts)
         }
      },

      // Updating the interface count in db
      function updtIntrFcCount(pathJson, counts, cb) {
         let {
            interfaceCount,
            intrSheets
         } = counts;
         if (interfaceCount > 0) {
            let intrFcArr = intrSheets.map((ele) => {
               let temp = {};
               temp.name = ele;
               return temp;
            })
            let url = `${host}${transIntrFUpdate}`;
            apiCall(url, headers, {
                  _id: runId,
                  updateData: intrFcArr,
                  type: "i-matrix"
               }, "post")
               .then((apiCallstatus) => {
                  if (apiCallstatus)
                     cb(null, pathJson, counts)
                  else
                     cb(new Error("System Error"))
               })
               .catch(() => {
                  cb(new Error("System Error"))
               })
         } else {
            cb(null, pathJson, counts)

         }
      },

      // Interface Matrix execution
      function executeInterface(pathJson, counts, cb) {
         let {
            interfaceCount,
            intrSheets
         } = counts;
         if (interfaceCount > 0) {
            crtIntrFcMatrix(intrSheets, interfaceCount, pathJson, hexFlag, errTxt)
               .then((imatrixStatus) => {
                  if (imatrixStatus)
                     cb(null)
                  else {
                     errFlag = true;
                     cb(null)
                  }
               })
               .catch(() => {
                  cb(new Error("System Error"))
               })
         } else {
            cb(null)
         }
      },

      // creating error report if it is there
      function errorReport(cb) {
         if (errTxt.length > 0 || errFlag === true) {
            let tempTxt = errTxt.toString().replace(/,/g, "");
            let heading = `The Excel file has the following errors:\n`;
            let runDir = path.resolve("../_RUNS");
            let resultDir = path.join(runDir, runId, "results")
            let pdfTxt = `${heading}${tempTxt}`
            let errFile = path.join(resultDir, "error_report.pdf");
            crtPdf(pdfTxt, errFile)
               .then((pdfRes) => {
                  allSuccess = false;
                  if (pdfRes)
                     cb(null)
                  else
                     cb(new Error("System Error"))
               })
               .catch(() => {
                  cb(new Error("System Error"))
               })
         } else
            cb(null)
      },

      // updating the final status as 3 or 4 based on Flag
      function finalStatus(cb) {
         let url = `${host}${statusUpdate}`;
         let status = allSuccess === true ? 3 : 4;
         apiCall(url, headers, {
               _id: runId,
               status
            }, "post")
            .then((apiStatus) => {
               if (apiStatus)
                  cb(null)
               else
                  cb(new Error("System Error"))
            })
            .catch(() => {
               cb(new Error("System Error"))
            })

      },

      // removing the schedule from schedules.json
      function removeSchedule(cb) {
         updtSchedule(runId, "remove")
            .then((rmBool) => {
               rmBool === true ? cb(null) : cb(new Error("System Error"))
            })
            .catch(() => {
               cb(new Error("System Error"))
            })
      }

   ], (err) => {
      if (err) {
         let defaultTxt = `Due to system error we are unable to process the file.Please try again later.`;
         let pdfTxt = errFlag === true ? err : defaultTxt;
         let runDirectory = path.resolve("../_RUNS");
         let errFile = path.join(runDirectory, runId, "results", "error_report.pdf");
         let url = `${host}${statusUpdate}`;
         (async () => {
            await crtPdf(pdfTxt, errFile);
            await apiCall(url, headers, {
               _id: runId,
               status: 4
            }, "post")
            await updtSchedule(runId, "remove")
         })()
      } else {
         console.log("All process completed")
      }

   })
}

const crtTransacMatrix = async (tranSheets, transactionCount, pathJson, hexFlag, errTxt) => {
   let matrixType = "t-matrix";
   return new Promise((resolve, reject) => {
      async.timesSeries(transactionCount, async (n) => {
         // console.log(n, " n ")
         let sheetName = tranSheets[n];
         let valid = await validate.validTrnSheet(pathJson, sheetName, errTxt);
         // console.log(valid, " valid ")
         if (valid) {
            let xmlResult = await tcrtXML.crtXML(pathJson, sheetName, hexFlag, errTxt);
            if (xmlResult) {
               await batFile.execute(pathJson, matrixType, sheetName);
               let conversionRes = await readCsv.csvToJSON(pathJson, matrixType, sheetName, errTxt);
               // console.log(conversionRes, " t-matrix - conversionRes ")
               if (conversionRes)
                  await twrtXL.writeToXL(pathJson, sheetName, hexFlag);
            }
         }
      }, (err) => {
         if (err)
            reject(false)
         else
            resolve(true);
      })
   })
}

const crtIntrFcMatrix = async (intrSheets, interfaceCount, pathJson, hexFlag, errTxt) => {
   let sheetName = intrSheets[interfaceCount - 1];
   // console.log(sheetName, " interfaceSheet")
   let matrixType = "i-matrix";
   return new Promise((resolve, reject) => {
      try {
         (async () => {
            let valid = await validate.validIntrFcSheet(pathJson, sheetName, errTxt);
            // console.log(valid, " valid")
            if (valid) {
               let xmlResult = await icrtXML.crtXML(pathJson, sheetName, errTxt, hexFlag);
               if (xmlResult) {
                  await batFile.execute(pathJson, matrixType, sheetName);
                  let conversionRes = await readCsv.csvToJSON(pathJson, matrixType, sheetName, errTxt);
                  // console.log(conversionRes, " result ")
                  if (conversionRes)
                     await iwrtXL.writeToXL(pathJson, sheetName, hexFlag);
               }
               resolve(true)
            } else {
               resolve(false)
            }
         })();
      } catch (error) {
         reject(false)
      }
   })
}