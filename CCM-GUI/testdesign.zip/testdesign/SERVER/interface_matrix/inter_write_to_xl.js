const Excel = require("exceljs");
const async = require("async");
const fs = require("fs")
const path = require("path");
const uniqId = require("uniqid");
const _ = require("lodash");

// Writing the Transaction Matrix to the copied XL File
exports.writeToXL = (paths, sheetName) => {
   let {
      results,
      interfaceMat
   } = paths;
   const workbook = new Excel.Workbook();
   return new Promise((resolve, reject) => {
      async.waterfall([
            getCopiedFilename,
            getProductNames,
            getLastRow,
            getJSONData,
            prepareRows,
            crtTable,
            writeToXLSheet
         ],
         (err) => {
            if (err) {
               reject(err);
            } else {
               resolve(true)
            }
         })
   })

   // Function to get the copied Filename
   function getCopiedFilename(callBack) {
      if (fs.existsSync(results)) {
         let filename = path.join(results, "results.xlsx");
         callBack(null, filename)
      } else {
         callBack(new Error("Results folder doesn't exixt"))
      }
   }

   // Function to get the product names from the products.json
   function getProductNames(filename, callBack) {
      let prodPath = path.join(interfaceMat, sheetName, "iMtrx_intrFcName.json")
      fs.readFile(prodPath, "utf-8", (err, prodName) => {
         if (err)
            callBack(err)
         else {
            let productNames = prodName;
            // console.log(productNames, " prodName ", typeof (productNames))
            callBack(null, filename, productNames)
         }
      })
   }
   // Function to get the Last Row based on tags
   function getLastRow(filename, productNames, callBack) {
      // console.log(filename, " filename ")
      let intrFcTags = {};
      workbook.xlsx.readFile(filename)
         .then(() => {
            let ws = workbook.getWorksheet(sheetName);
            ws.eachRow((row, rowNumber) => {
               row.eachCell((cell) => {
                  if (cell.value === "#constraint-product-end") {
                     intrFcTags.lastRowNo = rowNumber;
                     intrFcTags.actualRowCount = ws.actualRowCount;
                     intrFcTags.productNames = JSON.parse(productNames);
                     intrFcTags.filename = filename;
                  }
               })
            })
            callBack(null, intrFcTags, ws);
         }).catch((err) => {
            callBack(err)
         })
   }

   // Function to get the products JSON Data
   function getJSONData(intrFcTags, ws, callBack) {
      let jsonPath = path.join(interfaceMat, sheetName, "iMtrxOutput.json")
      fs.readFile(jsonPath, "UTF-8", (err, jsonData) => {
         if (err) {
            callBack(err)
         } else {
            let actOutputDta = JSON.parse(jsonData);
            // console.log(intrFcTags, " intrFcTags  ")
            // console.log(" actOutputDta  ", actOutputDta)
            callBack(null, intrFcTags, actOutputDta, ws)
         }
      })
   }

   // Function to prepare the tables based on ACT Output
   function prepareRows(intrFcTags, actOutputDta, ws, callBack) {
      let {
         productNames,
      } = intrFcTags;

      let actOutputDtaLen = actOutputDta.length;
      let tableData = [];
      const crtTable = (arr, intrFcNm, code, counter) => {
         let arrLen = arr.length;
         let matrxRows = [];
         let matrxColumns = [];
         let tranSacName;
         for (let j = 0; j < arrLen; j++) {
            let rcrds = arr[j];
            if (j === 0) {
               let otherCol = [];
               let attrCol = [];
               let colmnNames = Object.keys(rcrds).map((curVal) => {
                  let val = curVal;
                  val = val.replace(/__/g, " ");
                  return val;
               })
               let colm = colmnNames.filter((currVal, index) => {
                  if (index !== 1)
                     return currVal;
               })
               colm.map((cuVal, index) => {
                  if (index <= 5) {
                     otherCol.push(cuVal)
                  } else {
                     attrCol.push(cuVal)
                  }
               })
               otherCol.splice(1, 0, attrCol)
               let arrangedCol = _.flattenDeep(otherCol);
               matrxColumns.push(...arrangedCol);
            }
            if (rcrds["Interface"] === intrFcNm && rcrds["Id"] === code) {
               tranSacName = rcrds["Transactions"];
               let otherValues = [];
               let attrValues = [];
               let filteredValues = Object.values(rcrds).filter((currVal, index) => {
                  if (index !== 1)
                     return currVal;
               })
               filteredValues.map((currVal, index) => {
                  let replacedVal = currVal && Buffer.from(currVal, "hex").toString("utf8");
                  if (index <= 5)
                     otherValues.push(replacedVal)
                  else
                     attrValues.push(replacedVal)
               })
               otherValues.splice(1, 0, attrValues)
               let values = _.flattenDeep(otherValues);
               let originalCode = Buffer.from(code, "hex").toString("utf8")
               values.unshift(`INTR_${originalCode}_00${j + 1}`)
               matrxRows.push(values)
            }
         }
         tableData.push({
            intrFcNm: Buffer.from(intrFcNm, "hex").toString("utf8"),
            code: Buffer.from(tranSacName, "hex").toString("utf8"),
            rows: matrxRows,
            columns: matrxColumns
         })
         counter++;
         intrFcTableCrtion(counter)
      }

      const intrFcTableCrtion = (counter) => {
         if (counter < actOutputDtaLen) {
            let intrFcNm = productNames[counter].split("__[[")[0];
            let code = productNames[counter].split("__[[")[1].replace("[[", "").replace("]]", "");
            let intrFcArr = actOutputDta[counter];
            crtTable(intrFcArr, intrFcNm, code, counter)
         } else {
            // console.log(JSON.stringify(tableData, null, 4), " tableData ")
            callBack(null, intrFcTags, tableData, ws)

         }
      }
      intrFcTableCrtion(0)
   }

   // Function to Add the Tables to worksheet
   function crtTable(intrFcTags, tableData, ws, callBack) {
      let {
         lastRowNo
      } = intrFcTags;
      let lstRwNo = lastRowNo + 4;
      let tableDataLen = tableData.length;
      for (let t = 0; t < tableDataLen; t++) {
         let colNm = tableData[t].columns;
         let columnArr = ["Interface ID", ...colNm]
         let intrFcName = `${tableData[t].intrFcNm}`;
         let code = `${tableData[t].code}`;
         let tableName = `${intrFcName}(${code}) Matrix`.trim();
         let rows = tableData[t].rows;
         let headStyle = {
            font: {
               name: "Calibri",
               size: 12,
               bold: true
            },
            width: 20
         }
         let columnStyle = {
            font: {
               name: "Calibri",
               size: 10
            },
            width: 20
         };

         let columns = columnArr.map((key, index) => {
            let val;
            val = {
               "name": key,
               filterButton: true,
               "style": columnStyle
            }
            if (index !== 0) {
               val = {
                  "name": key,
                  filterButton: true,
                  "style": columnStyle
               }
            } else {
               val = {
                  "name": key,
                  style: columnStyle
               }
            }
            return val;
         })
         // console.log(columnArr, " colmnArr ")
         // console.log(lstRwNo, " lstRwNo")
         let ref = `B${Number(lstRwNo + 3)}`;
         const headingRow = `B${Number(lstRwNo + 2)}`;
         ws.getCell(headingRow).value = tableName;
         ws.getCell(headingRow).style = headStyle;
         ws.addTable({
            name: `interface_table_${uniqId.time()}`,
            ref: ref,
            headerRow: true,
            columns: columns,
            rows: rows,
         });
         lstRwNo += rows.length + 5;
      }
      callBack(null, intrFcTags)
   }

   // Function to write the tables to XL sheet
   function writeToXLSheet(intrFcTags, callBack) {
      let {
         filename
      } = intrFcTags;
      workbook.xlsx.writeFile(filename).then(() => {
            callBack(null)
         })
         .catch((e) => {
            // console.log(e, " writing to the XL file error ");
            callBack(e)
         })
   }

}