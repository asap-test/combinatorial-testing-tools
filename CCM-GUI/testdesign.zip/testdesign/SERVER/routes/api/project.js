let express = require('express');
let router = express.Router();
let db = require('../../db');
let auth = require('../authController.js');
const _ = require('underscore');


router.post('/check', auth.verify, (req, res) => {
  db.prjDb.loadDatabase()
  db.prjDb.findOne({ _id: req.body.prjId, status: 1 }, { _id: 1, name: 1, desc: 1 }, (err, results) => {
    if (err) {
      res.status(500).send({ err: err, data: null });
    } else {
      if (!_.isEmpty(results)) {
        var payload = { userId: req.payloadData.userId, isAdmin: req.payloadData.isAdmin, projectId: req.body.prjId };
        var token = auth.generateAccessToken(payload);
        let prjRslt = { prjId: results._id, prjName: results.name, prjDesc: results.desc };
        res.status(200).send({ err: null, data: { authorization: token, prjDtls: prjRslt } });
      } else {
        res.status(200).send({ err: null, data: results });
      }
    }
  });
});

router.get('/list', auth.verify, function (req, res, next) {
  db.prjDb.loadDatabase()
  db.prjDb.find({},(err,results)=>{
    if (err) {
      res.status(500).send({ err: err.message, data: null });
    } else {
      let data = results.map((el)=>{
        let temp = {};
        temp.prjId = el["_id"];
        temp.prjName = el["name"];
        temp.prjDesc = el["desc"];
       return temp;

      })
      res.status(200).send({ err: null, data: data });

    }

  })
});

module.exports = router;
