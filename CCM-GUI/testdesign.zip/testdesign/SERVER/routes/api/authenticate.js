const express = require('express'),
  router = express.Router(),
  db = require('../../db')
  auth = require('../authController.js'),
  async = require('async');

router.post('/', auth.platformVerify, function (req, res, next) {
  db.prjDb.loadDatabase();
  db.userDb.loadDatabase();
  let pfmPayload = req.platformPayload;
  // console.log(pfmPayload , "  pfmPayload     ")
  let isAdmin = ((pfmPayload) ? 'Y' : 'N')
  var bulkUpdInsStmt = []
  let pfmPrjList = pfmPayload.projectList
  var pfmPrjIds = [];
  var prjIds;
  var usrDetails;

  async.series({
    "projectUpdateInsert": function (callback) {
      let errFlag = false;
      pfmPrjList.forEach(prjRecords => {
        // console.log(prjRecords , " prjRecords ")
        pfmPrjIds.push(prjRecords.prjId)
        db.prjDb.update({  platform_id: prjRecords.prjId }, { name: prjRecords.prjName, desc: prjRecords.prjDesc, platform_id: prjRecords.prjId, status: 1 }, { upsert: true },  (err, numReplaced, upsert) =>{
          // console.log(upsert , " upsert  ")
          // console.log(numReplaced , " numReplaced  ")
          if(err)
            errFlag = true;
        });
      })
      if(errFlag){
        callback(r.writeErrors, 'Failed', '');
      }
      else{
        callback(null, 'Success', '');
      }
    },
    "projectList": function (callback) {
      db.prjDb.find({ platform_id: { $in: pfmPrjIds } }, { _id: 1 }, function (err, results) {
        if (err) {
          callback(err, 'Failed', '');
        }
        else {
          // console.log(results , " ProjectList >>>>>>>> ")
          let tmpProjectIds = []
          results.forEach(tmpPrjIds => {
            tmpProjectIds.push(tmpPrjIds._id.toString());
          });
          prjIds = tmpProjectIds
          callback(null, 'Success', '');
        }
      })
    },
    "userUpdateInsert": function (callback) {
      db.userDb.update(
        { email: pfmPayload.userEmail },
        {
          $set: {
            fname: pfmPayload.userFName, lname: pfmPayload.userLName,
            email: pfmPayload.userEmail, project_id: prjIds, status: 1
          }
        },
        { upsert: true ,returnUpdatedDocs:true },
       (err, numReplaced,affectedDocuments, upsert)=> {
          if (err) {
            callback(err, 'Failed', '');
          } else {
            usrDetails = affectedDocuments;
            callback(null, 'Success', '');
          }
        });
    }
  },
     (err, results)=> {
      // console.log(results , " <<<<<<<<<< results >>>>>>>>>>>>> ")
      if (err) {
        res.status(401).send({ err: err, data: { msg: "Unauthorized" } });
      } else {
        // console.log(usrDetails , "  usrDetails ")
        var payload = { userId:  `${usrDetails.fname}`, isAdmin: isAdmin };
        var token = auth.generateAccessToken(payload);
        let tmpUsrDetails = { usrId: `${usrDetails._id}`, fName: `${usrDetails.fname}`, lName: `${usrDetails.lname}` };
        // let usrRslt = JSON.parse('{ "authorization": "' + token + '", "usrDtls": ' + JSON.stringify(tmpUsrDetails) + ' }')
        res.status(200).send({ err: null, data: { authorization: token, usrDtls: tmpUsrDetails } });
      }
    });
});

module.exports = router;
