const express = require('express'),
  router = express.Router(),
  mongoose = require("mongoose"),
   db = require('../../db'),
  auth = require('../authController.js');
  
router.get('/jobs', auth.apiVerify, function (req, res) {
   db.schdlDb.loadDatabase()
  // mSchedule.find({status:1},{_id:1}).sort(createdAt: 1)
  db.schdlDb.find({
    status: 1
  }).sort({'createdAt':1}).limit(1).exec(function (err, result) {
    // console.log(result , " result ")
    if (err) {
      console.log(err);
      res.status(500).send({
        err: err.message,
        status: "error",
        data: null
      });
    } else if (result.length == 0) {
      res.setHeader('Content-Type', 'application/json');
      res.status(204).send({
        err: null,
        status: "no-records",
        data: null
      });
    } else {
      res.setHeader('Content-Type', 'application/json');
      res.status(200).send({
        err: null,
        status: "success",
        data: {
          schdId: result[0]._id
        }
      });
    }
  });
});

router.post('/statusUpdate', auth.apiVerify, function (req, res) {
  db.schdlDb.loadDatabase()
  let {
    status,
    _id
  } = req.body;
  db.schdlDb.update({
    _id: _id
  }, {
    $set: {
      status: Number(status),
    }
  }, (err) => {
    db.schdlDb.persistence.compactDatafile()
    if (err) {
      console.log(err);
      res.status(500).send({
        err: err.message,
        status: "error",
        data: null
      });
    } else {
      res.setHeader('Content-Type', 'application/json');
      res.status(200).send({
        err: null,
        status: "success",
        data: null
      });
    }
  });
})

router.post('/transIntrfUpdate', auth.apiVerify, function (req, res, next) {
  db.schdlDb.loadDatabase()
  let {
    _id,
    updateData,
    type,
  } = req.body
  let updateQuery = {};
  type === "t-matrix" ? updateQuery["trans"] = updateData : updateQuery["intf"] = updateData
  //console.log(updateQuery, " updateQuery ")
  db.schdlDb.update({
    _id: _id
  }, {
    $set:updateQuery
  }, (err) => {
    if (err) {
      console.log(err);
      res.status(500).send({
        err: err.message,
        status: "error",
        data: null
      });
    } else {
      res.setHeader('Content-Type', 'application/json');
      res.status(200).send({
        err: null,
        status: "success",
        data: null
      });
    }
  });
});

module.exports = router;
