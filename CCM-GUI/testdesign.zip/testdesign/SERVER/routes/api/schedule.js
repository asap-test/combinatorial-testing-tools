const express = require('express'),
  router = express.Router(),
  async = require('async'),
  db = require('../../db'),
  _ = require('underscore'),
  auth = require('../authController.js');

let multer = require('multer');
let fs = require('fs');
let path = require('path');

let pathConfig = path.resolve("../_RUNS");
console.log(pathConfig,"PathConfig")


var storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads")
  },
  filename: (req, file, cb) => {
    let fileType = file.originalname.split('.');
    cb(null, Date.now() + '.' + fileType[fileType.length - 1])
  }
})
let upload = multer({ storage: storage }).single('file');

// Schedule Delete
router.post('/delete', auth.verify, (req, res) => {
  mSchedule.updateOne({ _id: mongoose.Types.ObjectId(req.body._id), project_id: req.payloadData.projectId },
    { $set: { status: 0 } }, (err, results) => {
      if (err) {
        res.status(500).send({ err: err.message, data: null });
      } else if (results.nModified === 0) {
        res.status(204).send({ err: null, data: { code: 201, msg: 'Not Updated' } });
      } else {
        res.status(200).send({ err: null, data: 'Successfully updated' });
      }
    })
});

// Schedules list
router.get('/list',auth.verify, (req, res) => {
    db.schdlDb.loadDatabase()
    db.schdlDb.find({project_id :req.payloadData.projectId}).sort({createdAt:-1}).exec((err, results) => {
    if (err) {
      res.status(500).send({ err: err.message, data: null });
    } else {
      let data = results.map((ele, index) => {
        let temp = ele;
        temp.sNo = index + 1;
        temp.usrFname = ele.usrId;
        return temp;
      })
      res.status(200).send({ err: null, data: data });
    }
  })
})

// Craeting and Uploading schedule , schedulefile
router.post('/uploadschdl',auth.verify, (req, res, next) => {
  let errResp = {
    msg: undefined,
    code: undefined
  };
  let schdlDoc = undefined;
  let allSuccess = false;
  async.series({
    createSchdl: cb => {
      let reqData = JSON.parse(req.headers.data);
      let schdl = {};
      schdl.name = reqData.name;
      schdl.desc = reqData.desc;
      schdl.status = 1;
      schdl.fileName = reqData.shdlFileNm;
      schdl.project_id = req.payloadData.projectId 
      schdl.usrId = req.payloadData.userId
      schdl.createdAt = Date.now()
      db.schdlDb.insert(schdl , (err,doc)=>{
        if (err) {
          cb(err);
        } else {
          schdlDoc = doc;
          cb(null);
        };

      })
    },
    uploadSchdlFile: cb => {
      uploadFile(req, res, (err, filePath) => {
        let fileName = filePath.split('\\')[1];
        if (err) {
          db.schdlDb.deleteOne({ _id: mongoose.Types.ObjectId(doc._id) }, (err, docs) => {
            if (err) cb(err);
            else {
              cb(null);
            }
          });
        } else {
          allSuccess = true;
          fs.mkdir(`${pathConfig}/${schdlDoc._id}/source`, { recursive: true }, (err) => {
            if (err) cb(err);
            else {
              let results = path.join(`${pathConfig}`, `${schdlDoc._id}`, "results");
              fs.copyFile(filePath, `${pathConfig}/${schdlDoc._id}/source/source.xlsx`, (err) => {
                if (!err) {
                  fs.unlinkSync(filePath);
                  fs.mkdirSync(results)
                  allSuccess = true;
                  cb(null)
                } else {
                  cb(err);
                }
              })
            }
          })
        };
      })
    }
  }, (err) => {
    if (err) {
      res.status(500).send({ err: err, data: null });
    } else {
      if (allSuccess) {
        res.status(200).send({ err: null, data: 'Successfully Saved' });
      } else {
        res.status(200).send({ err: null, data: { msg: 'Something Went wrong', code: 201 } });
      }
    }
  })
});

// Downloading the results of the schedule ID based on status(3/4)
router.get('/downloadschdl/:_id', auth.verify, (req, res) => {
  let _id = req.params._id;
  let downloadPath;
  let file;
  db.schdlDb.findOne({ _id: _id ,project_id : req.payloadData.projectId }, (err, results) => {
    if (err) {
      res.status(500).send({ err: err, data: null })
    }
    else if (results !== null) {
      let { status, name, fileName } = results;
      let downloadFile = status === 3 ? "results.xlsx" : "error_report.pdf";
      let runIdPath = path.join(pathConfig, _id, "results");
      // console.log(runIdPath , " runIdPath ")
      downloadPath = path.join(runIdPath, downloadFile);
      file = status === 3 ? `${fileName}` : "error_report.pdf";
      res.download(downloadPath, file)
      console.log("Successfully downloaded")
    }
    else {
      res.status(500).send({ err: err, data: null })
    }
  })
})


// Uploading File with response in multer
let uploadFile = (req, res, cb) => {
  upload(req, res, (err, data) => {
    cb(err, req.file.path);
  })
}

module.exports = router;
