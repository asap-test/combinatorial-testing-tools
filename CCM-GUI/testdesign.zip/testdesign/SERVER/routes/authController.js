
const jwt = require('jsonwebtoken'),
  crypto = require('crypto-js'),
  moment = require('moment'),
  secret = require('../config/authConfig').secret,
  cryptokey = require('../config/authConfig').cryptokey,
  db = require('../db');

var auth = {
  generateAccessToken: function (payload) {
    // Default algorithm will be HS256
    var token = jwt.sign(payload, secret, { expiresIn: "12h" });
    return token
  },

  verify: function (req, res, next) {
    try {
      var payload = req.headers.authorization;
      var legit = jwt.verify(payload, secret, { expiresIn: "12h" });
      req.payloadData = legit;
      next();
    }
    catch (err) {
      res.status(401).send({ err: err.message, status: "unauthorized" });
    }
  },

  platformVerify: function (req, res, next) {
    // let platformToken = req.headers.platformtoken;
    let platformToken = req.body.platformtoken;
    let decryptData = crypto.AES.decrypt(platformToken.toString(), cryptokey.toString());
    // console.log(decryptData , " decryptData ")
    req.platformPayload = JSON.parse(decryptData.toString(crypto.enc.Utf8));
    // console.log(req.platformPayload , " platformPayload ")
    if (typeof (req.platformPayload) === 'string') {
      req.platformPayload = JSON.parse(req.platformPayload);
    }
    // console.log(decryptData.toString(crypto.enc.Utf8))
    // console.log(req.platformPayload.expiry)
    let tokenExpiry = moment(moment.utc(req.platformPayload.expiry)).isAfter(moment.utc());
    let toolCode = req.platformPayload.tool;
    // console.log(tokenExpiry)

    if (tokenExpiry === true && toolCode === 'TB') {
      next();
    } else {
      res.status(401).send({ err: null, data: { msg: "Unauthorized" } });
    }
  },
  apiVerify: function (req, res, next) {
    let engineId = req.headers.engineid;
    let apiKey = req.headers.apikey;
    if (!engineId || !apiKey) {
      res.setHeader('Content-Type', 'application/json');
      res.status(401).send({
        err: 'Engine or API Key missing',
        status: "unauthorized"
      });
    } else {
      db.engineDb.find({
        _id: engineId,
        apiKey: apiKey,
        status: 1
      }, {
        _id: 1
      },  (err, results)=> {
        if (err) {
          console.log(err);
          res.status(500).send({
            err: err,
            status: "error",
            data: null
          });
        } else if (results == null) {
          res.setHeader('Content-Type', 'application/json');
          res.status(401).send({
            err: null,
            status: "unauthorized"
          });
        } else {
          next();
        }
      })
    }
  }
}

module.exports = auth;
