const CronJob = require("cron").CronJob;
const moment = require("moment");
const fs = require("fs");
const path = require("path");
const {
   apiCall,
   crtPdf,
   updtSchedule
} = require("./utils/utils");
const constants = require("./config/constants").constants;

// API files
const apimatrix = require("./apilogics/apimatrix");

const runScheduleId = () => {
   const job = new CronJob('*/30 * * * * *', async () => {  
      try {
         let runDir = path.resolve("../_RUNS");
         // console.log(runDir , " run Dir >>>>>>>>>>>>>>>> ")
         let schedulePath = path.join(runDir, "schedules.json");
         // console.log(schedulePath , " schedulePath >>>>>>>>>>>>>>>> ")
         let fileData = fs.readFileSync(schedulePath, "utf-8");
         // console.log(fileData , "fileData >>>>>>>>>>>>>>>> ")
         let stats = fs.statSync(schedulePath);
         let begiTime = moment().format("YYYY-MM-DD HH:mm:ss");
         let endTime = moment(stats.mtime).format("YYYY-MM-DD HH:mm:ss");
         let difference = moment(begiTime).diff(moment(endTime), "minutes");
         // console.log(stats, " stats ")
         // console.log(`${stats.mtime} - m-stats && difference - ${difference}`)
         let schedules = JSON.parse(fileData).schedules;
         let host = constants.host;
         let url = `${host}/api/engine/schedule/jobs`
         let engineId = constants.engineId;
         let apiKey = constants.apiKey;

         // Update the Status as Error & Remove the run ID when the status is Processing for more then 15 minutes
         if (difference > 15 && schedules.length > 0) {
            let statusUpdtUrl = `${host}/api/engine/schedule/statusUpdate`;
            let apiCallStatus = await apiCall(statusUpdtUrl, {
               engineId,
               apiKey
            }, {
               _id: schedules,
               status: 4
            }, "post")
            if (apiCallStatus) {
               await updtSchedule("", "remove")
               let runDir = path.resolve("../_RUNS");
               let resultDir = path.join(runDir, schedules, "results")
               let errFile = path.join(resultDir, "error_report.pdf");
               let pdfTxt = `Please correct the file and upload again.\nBelow are the possible errors.\n1)Ensure Attribute & value name in Product Mapping and Constraints match(case sensitive & spelling) in Transaction Sheet.\n2)The Attribute name should not contain any special character in Interface Sheet.\n3)Duplicate Attributes are not allowed within a transaction.\n4)Duplicate Values are not allowed within an attribute.\n5)Ensure Test Methodology column is filled with numeric value in the Transaction Sheet.\n6)For values with "%" the cell format should be TEXT and not PERCENTAGE.\n\n`
               let pdfRes = await crtPdf(pdfTxt, errFile)
               if (pdfRes) {
                  console.log("File Status Changed from Processing to Error!")
               }
            } else {
               console.log("Error in Removing the schedule ID")
            }
         }
         const response = await apiCall(url, {
            engineId,
            apiKey
         }, {}, "get")
         // console.log(response, " response ")
         if (response.data && response.data.data) {
            let {
               schdId
            } = response.data.data;
            // console.log(schdId, " schdId ")
            if (schedules.length === 0)
               apimatrix.run(schdId);
         }
      } catch (e) {
         console.log(e, " catch block error in index.js ")
      }
   });
   job.start();
}

module.exports = {
   runScheduleId:runScheduleId
};
