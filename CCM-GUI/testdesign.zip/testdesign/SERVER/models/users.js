var mongoose = require('mongoose');

var UserSchema = new mongoose.Schema({
    email: { type: String, required: [true, "can't be blank"] },
    fname: { type: String, required: [true, "can't be blank"] },
    lname: { type: String, required: [true, "can't be blank"] },
    project_id: {type: Array},
    status: { type: Number, default: 1 }
}, { timestamps: true });

module.exports = { users: mongoose.model('users', UserSchema) };
//mongoose.model('mUser', UserSchema);
