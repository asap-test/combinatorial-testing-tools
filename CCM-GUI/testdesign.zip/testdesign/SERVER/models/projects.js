var mongoose = require('mongoose');

var ProjectSchema = new mongoose.Schema({
    name: { type: String, required: [true, "Project name can't be blank"]},
    desc: { type: String},
    platformPrj_id : { type: String },
    status: { type: Number, default: 1 }
}, { timestamps: true });

module.exports = { projects: mongoose.model('projects', ProjectSchema) };