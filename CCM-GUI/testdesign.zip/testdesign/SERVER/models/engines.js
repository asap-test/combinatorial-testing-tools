var mongoose = require('mongoose');

var EngineSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, "Engine name can't be blank"]
    },
    apiKey: {
        type: String
    },
    status: {
        type: Number,
        default: 1
    }
}, {
    timestamps: true
});

module.exports = {
    engines: mongoose.model('engines', EngineSchema)
};