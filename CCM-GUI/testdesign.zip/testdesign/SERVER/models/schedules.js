var mongoose = require('mongoose');

var ScheduleSchema = new mongoose.Schema({
    name: { type: String, required: [true, "Schedule name can't be blank"] },
    desc: { type: String },
    project_id: { type: String, required: [true, "Project Id can't be blank"] },
    fileName: {type: String},
    trans: [
        {
            name: { type: String },
            status: { type: Number, default: 1 },
            stages:{
                stg_1: { type: Boolean, default: false},
                stg_2: { type: Boolean, default: false},
                stg_3: { type: Boolean, default: false},
                stg_4: { type: Boolean, default: false},
                stg_5: { type: Boolean, default: false},
                stg_6: { type: Boolean, default: false}
            }
        }
    ],
     intf: [{
        name: { type: String },
        status: { type: Number, default: 1},
        stages: {
            stg_1: { type: Boolean, default: false},
            stg_2: { type: Boolean, default: false},
            stg_3: { type: Boolean, default: false},
            stg_4: { type: Boolean, default: false},
            stg_5: { type: Boolean, default: false},
            stg_6: { type: Boolean, default: false}
        }
    }],
    status: { type: Number, default: 1 },
    usrId: { type: String, required: [true, "User Id can't be blank"] }
}, { timestamps: true });

module.exports = { schedules: mongoose.model('schedules', ScheduleSchema) };
