// const csv = require('csvtojson')
const csv = require("csv-parser")
const fs = require("fs");
const path = require("path");
const async = require("async");


// function to convert the CSV from ACT Tool to JSON
exports.csvToJSON = (paths, matrixType, sheetName, errTxt) => {
   let csvFiles = [];
   let finalResult = [];
   let {
      transMat,
      interfaceMat
   } = paths;

   return new Promise((resolve, reject) => {
      async.waterfall([
         getCSVFiles,
         readCSVFile,
         tallyOutput,
         writeJSON
      ], (err, bool) => {
         if (err) {
            reject(err)
         } else {
            resolve(bool)
         }
      })
   })

   // get all the CSV files from the CSV folder
   function getCSVFiles(cb) {
      let CSV_path = matrixType === "t-matrix" ? path.join(transMat, sheetName, "CSV") : path.join(interfaceMat, sheetName, "CSV");
      try {
         let fileNames = fs.readdirSync(CSV_path)
         fileNames.forEach(file => {
            if (path.extname(file) === ".csv") {
               csvFiles.push(file);
            }
         })
         const sortAlphaNum = (a, b) => a.localeCompare(b, "en", {
            numeric: true
         });
         csvFiles.sort(sortAlphaNum);
         console.log(csvFiles, " csvFiles ")
         cb(null, CSV_path)
      } catch (err) {
         cb(new Error("Error in reading csv directory"))
      }
   }

   // Read the CSV files and creating the Products JSON
   function readCSVFile(CSV_path, cb) {
      // using CSV-PARSER Module
      const readCSV = (csvCounter) => {
         let file = path.join(CSV_path, csvFiles[csvCounter])
         // console.log(file, " file  ")
         let tempData = [];
         fs.createReadStream(file)
            .pipe(csv({
               skipComments: true
            }))
            .on("data", (data) => {
               let jsonData;
               jsonData = data;
               if (matrixType === "t-matrix") {
                  jsonData.type = "Positive";
                  let values = Object.values(jsonData);
                  values.forEach((ele) => {
                     let bool = ele.startsWith("[[N]]_");
                     if (bool === true) {
                        jsonData["type"] = "Negative";
                        return;
                     }
                  })
               }
               tempData.push(jsonData);
            })
            .on("end", () => {
               csvCounter++;
               finalResult.push(tempData);
               callCSV(csvCounter);
            })

      }
      const callCSV = (csvCounter) => {
         if (csvCounter < csvFiles.length) {
            readCSV(csvCounter);
         } else {
            // console.log(finalResult, " final Result ");
            cb(null)
         }
      }
      callCSV(0);
   }

   // function to tally the ACT CSV output with product name list
   function tallyOutput(cb) {
      let prodPath = matrixType === "t-matrix" ? path.join(transMat, sheetName, "tMtrxProdName.json") :
         path.join(interfaceMat, sheetName, "iMtrx_intrFcName.json");
      fs.readFile(prodPath, "utf-8", (err, prodName) => {
         if (err)
            cb(new Error("Error in reading the product names json"))
         else {
            let productNames = JSON.parse(prodName);
            let prodLen = productNames.length;
            let csvFilesLen = csvFiles.length;
            let errorProducts = [];
            let csvIndex = csvFiles.map((csvVal) => Number(csvVal.split(".csv")[0].replace("p_", "")))
            if (prodLen === csvFilesLen) {
               cb(null, true)
            } else {
               productNames.map((val, index) => {
                  csvIndex.includes(index) === false ? errorProducts.push(val) : errorProducts;
               })
               let errors = ``;
               let product = matrixType === "t-matrix" ? "products" : "interface";
               errorProducts.map((val, index) => {
                  let vl = matrixType !== "t-matrix" ? val.split("__")[0] : val;
                  if (matrixType !== "t-matrix") {
                     errors += `${index+1})${Buffer.from(vl, "hex").toString("utf8")}\n`;
                  } else {
                     errors += `${index+1})${vl}\n`
                  }
               });
               let errorText = ``;
               let note_1 = ``;
               if (matrixType === "t-matrix") {
                  note_1 = `1)Ensure Attribute & value name in Product Mapping and Constraints match(case sensitive & spelling).\n`;
               } else {
                  note_1 = `1)The Attribute name should not contain any special character.\n`;
               }
               errorText = `${sheetName} sheet might have the below errors.\nPlease correct the file and upload again.\nBelow are the following ${product}\n${errors}\nNote:\n${note_1}2)Duplicate Attributes are not allowed within a transaction.\n3)Duplicate Values are not allowed within an attribute.\n4)Ensure Test Methodology column is filled with numeric value in the Transaction Sheet.\n5)For values with "%" the cell format should be TEXT and not PERCENTAGE.\n\n`
               errTxt.push(errorText);
               cb(null, false);
            }
         }
      })

   }

   // function to write the Product JSON
   function writeJSON(bool, cb) {
      if (bool) {
         let prdtName = matrixType === "t-matrix" ? "tMtrxOutput.json" : "iMtrxOutput.json"
         let matrixPath = matrixType === "t-matrix" ? path.join(transMat, sheetName) : path.join(interfaceMat, sheetName);
         const jsonFile = path.join(matrixPath, prdtName);
         fs.writeFile(jsonFile, JSON.stringify(finalResult, null, 2), (err) => {
            if (err)
               cb(new Error("Error in creating the product output"))
            else {
               cb(null, true)
            }
         })
      } else {
         cb(null, false)
      }
   }
}