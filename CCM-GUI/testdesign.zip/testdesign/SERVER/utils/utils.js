const fs = require("fs");
const path = require("path");
const PDFDocument = require("pdfkit");
const axios = require("axios");

// function to create the error pdf
exports.crtPdf = (errTxt, errFile) => {
   return new Promise((resolve, reject) => {
      try {
         const doc = new PDFDocument();
         doc.pipe(fs.createWriteStream(errFile));
         doc
            .font('Times-Roman')
            .fontSize(20)
            .text(errTxt, 100, 100)
            // .rect(doc.x, 0, 450, doc.y).stroke()
            .end();
         resolve(true);
      } catch (e) {
         console.log(e, " e  ")
         reject(false);
      }
   })
}


// Inserts the Run Id in schedules in  schedules.json or Empty the schedules in schedules.json
exports.updtSchedule = (runId, type) => {
   return new Promise((resolve, reject) => {
      let runDir = path.resolve("../_RUNS");
      let schedulePath = path.join(runDir, "schedules.json");
      try {
         let writeData = {};
         if (type === "insert")
            writeData["schedules"] = runId;
         else
            writeData["schedules"] = "";
         //console.log(writeData, "writeData");
         fs.writeFileSync(schedulePath, JSON.stringify(writeData), "utf8");
         resolve(true);
      } catch (error) {
         console.log(error)
         reject(false)
      }
   })
}

// Api calls using axios library
exports.apiCall = (url, headers, body, type) => {
   return new Promise((resolve, reject) => {
      // console.log(body , " body ")
      const config = {
         url: url,
         method: type,
         headers: headers
      }
      if (type === "post")
         config["data"] = body;
      (async () => {
         try {
            // console.log(config , " config ")
            let response = await axios(config);
            // console.log(response , " response ")
            resolve(response);
         } catch (e) {
            reject(false);
         }
      })()
   })
}