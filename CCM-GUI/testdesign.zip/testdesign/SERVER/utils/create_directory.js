const fs = require("fs");
const Excel = require("exceljs");
const path = require("path");


// creating directories inside _runs folder
exports.crtDirectories = (paths) => {
   return new Promise((resolve, reject) => {
      let {
         runIdPath,
         transMat,
         interfaceMat
      } = paths;
      let configData;
      let configFile = path.join(runIdPath, "source", "config.json");
      fs.readFile(configFile, "utf8", (err, jsonData) => {
         if (err)
            reject(new Error("Error in reading config file"))
         else {
            configData = JSON.parse(jsonData);
            let transactionCount = configData["tranNames"].length;
            let interfaceCount = configData["intrFcName"].length;
            let tranSheets = configData["tranNames"].map((ele) => ele.name);
            let intrSheets = configData["intrFcName"].map((el) => el.name);
            for (let t = 0; t < transactionCount; t++) {
               let sheetTran = path.join(transMat, tranSheets[t]);
               let transXML = path.join(sheetTran, "XML");
               let transCSV = path.join(sheetTran, "CSV");
               let transFolder = [sheetTran, transXML, transCSV]
               for (let k = 0; k < transFolder.length; k++) {
                  fs.mkdirSync(transFolder[k])
               }
            }
            if (interfaceCount > 0) {
               let sheetIntr = path.join(interfaceMat, intrSheets[0]);
               let intrXML = path.join(sheetIntr, "XML");
               let intrCSV = path.join(sheetIntr, "CSV");
               let intrFolder = [sheetIntr, intrXML, intrCSV];
               for (let k = 0; k < intrFolder.length; k++) {
                  fs.mkdirSync(intrFolder[k])
               }
            }
            resolve({
               tranSheets,
               transactionCount,
               intrSheets,
               interfaceCount
            })
         }
      })
   })
}

// reading config sheet in XL book
exports.readConfig = (runId) => {
   return new Promise((resolve, reject) => {
      let pathJson = {};
      let runDir = path.resolve("../_RUNS");
      let runIdPath = path.join(runDir, runId)
      let sourcePath = path.join(runIdPath, "source");
      let errorSheet = [];
      let errFlag = false;

      // _runs  run ID folder , source folder , source.xlsx , in source xl check _config
      let results = path.join(runIdPath, "results");
      let transMat = path.join(results, "t-matrix");
      let interfaceMat = path.join(results, "i-matrix")
      let baseFolders = [transMat, interfaceMat]
      try {
         for (let i = 0; i < baseFolders.length; i++) {
            if (!fs.existsSync(baseFolders[i])) {
               fs.mkdirSync(baseFolders[i])

            }
         }
         let srcFile = path.join(sourcePath, "source.xlsx");
         if (fs.existsSync(srcFile)) {
            let workbook = new Excel.Workbook();
            workbook.xlsx.readFile(srcFile)
               .then(() => {
                  let sheets = workbook.worksheets.map((sheet) => {
                     return sheet.name;
                  })
                  //console.log(sheets, " sheets ", sheets.includes("_config"))
                  if (sheets.includes("_config")) {
                     let ws = workbook.getWorksheet("_config");
                     let temp = [];
                     let sheetNames;
                     let firstRow;
                     ws.eachRow((row, rowNumber) => {
                        row.eachCell((cell) => {
                           if (cell.value === "Transaction Name") {
                              firstRow = rowNumber;
                           }
                           if (rowNumber > firstRow) {
                              temp.push(Object.values(row.values))
                           }
                        })
                     })
                     sheetNames = Array.from(new Set(temp.map(JSON.stringify)), JSON.parse);
                     // console.log(sheetNames, " sheetNames ");
                     let configData = {};
                     configData.tranNames = [];
                     configData.intrFcName = [];
                     sheetNames.map((currVal) => {
                        let name = currVal[0];
                        let option = currVal[1];
                        if (name !== "Interface" && option === "Y") {
                           configData.tranNames.push({
                              name: name.trim(),
                              status: 0
                           })
                        } else if (name === "Interface" && option === "Y") {
                           configData.intrFcName.push({
                              name: name.trim(),
                              status: 0
                           })
                        }
                     })


                     if (configData.tranNames.length > 0) {
                        configData.tranNames.map((sh) => {
                           if (!(sheets.includes(sh.name))) {
                              errorSheet.push(sh.name);
                              errFlag = true;
                           }
                        })
                     }

                     if (configData.intrFcName.length > 0) {
                        configData.intrFcName.map((sh) => {
                           if (!(sheets.includes(sh.name))) {
                              errorSheet.push(sh.name);
                              errFlag = true;
                           }
                        })
                     }

                     if ((configData.tranNames.length > 0 && errFlag === false) || (configData.intrFcName.length > 0 && errFlag === false)) {
                        let configJsonPath = path.join(sourcePath, "config.json")
                        fs.writeFile(configJsonPath, JSON.stringify(configData), "utf-8", (err) => {
                           if (err) {
                              reject(new Error("Error in creating config.json"))
                           } else {
                              pathJson["runIdPath"] = runIdPath;
                              pathJson["sourcePath"] = sourcePath;
                              pathJson["results"] = results;
                              pathJson["transMat"] = transMat;
                              pathJson["interfaceMat"] = interfaceMat;
                              resolve(pathJson);
                           }
                        })
                     } else if (errorSheet.length > 0 && errFlag === true) {
                        let errTags = ``;
                        errorSheet.map((val, index) => {
                           errTags += `${index+1})${val}\n`
                        });
                        let errTxt = `The Excel file has the following errors:\n_config sheet has transaction names which are not available.Please correct the Excel and upload again.Below are the  missing transactions:\n${errTags}`;
                        resolve(errTxt)
                     } else {
                        let errTxt = `The Excel file has the following error:\n_config sheet must have the "Transaction Name" keyword and minimum one transasction is marked as Y in Run field to process the file.Please update the _config sheet and upload again`;
                        resolve(errTxt)
                     }
                  } else {
                     let errTxt = `The Excel has the following error:\n_config sheet is missing in the Excel workbook. Please add the _config sheet and upload again.`;
                     resolve(errTxt)
                  }
               })
               .catch((error) => {
                  reject(error)
               })
         } else {
            reject(new Error("Source Path Doesn't Exist"))
         }
      } catch (err) {
         reject(new Error("Error in folder creation"))
      }
   })
}