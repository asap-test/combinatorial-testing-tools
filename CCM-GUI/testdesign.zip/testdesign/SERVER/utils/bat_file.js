const path = require("path");
const fs = require("fs");
const async = require("async");
const os = require("os");
let osType = os.type();

// Execution of Batfile - Creating commands dynamically using the product names
exports.execute = (paths, matrixType, sheetName) => {
   let {
      transMat,
      interfaceMat,
      results
   } = paths;

   return new Promise((resolve, reject) => {
      console.time("Bat File Execution")
      async.waterfall([
         prodNames,
         crtBatFile,
         runBatFile
      ], (err) => {
         if (err) {
            console.log(err, " err ")
            reject(err)
         } else {
            console.timeEnd("Bat File Execution")
            resolve("Bat File Execution completed")
         }
      })
   })

   // Reading the product Names from the product file
   function prodNames(cb) {
      const prodPath = matrixType === "t-matrix" ? path.join(transMat, sheetName, "tMtrxProdName.json") : path.join(interfaceMat, sheetName, "iMtrx_intrFcName.json");
      const XMLPath = matrixType === "t-matrix" ? path.join(transMat, sheetName, "XML") : path.join(interfaceMat, sheetName, "XML");
      const csvPath = matrixType === "t-matrix" ? path.join(transMat, sheetName, "CSV") : path.join(interfaceMat, sheetName, "CSV");
      fs.readFile(prodPath, "utf-8", (err, prodData) => {
         if (err) {
            console.log(err);
            cb(err)
         } else {
            let prodName = JSON.parse(prodData);
            let prodLen = prodName.length;
            let fullCommand;
            fullCommand = (osType !== "Linux") ? `@echo off\n` : `#!/bin/sh\n`;
            for (let i = 0; i < prodLen; i++) {
               let command;
               let xmlStr;
               xmlStr = `p${i}.xml`;
               let csvStr = `p_${i}.csv`;
               let XMLFile = path.join(XMLPath, xmlStr)
               let csvFile = path.join(csvPath, csvStr)
               if (osType !== "Linux") {
                  command = `start "Product${i+1}" java -Doutput=csv -Ddoi=1 -jar acts_3.2.jar`
                  fullCommand += `${command} "${XMLFile}" "${csvFile}"\n`
               } else {
                  command = `nohup java -Doutput=csv -Ddoi=1 -jar acts_3.2.jar`
                  fullCommand += (i < prodLen - 1) ? `${command} "${XMLFile}" "${csvFile}" &\n` :
                     `${command} "${XMLFile}" "${csvFile}"\n`
               }


            }
            //console.log(XMLPath, " XMLPATH ");
            //console.log(csvPath, " csvPath ");
            //console.log(prodName, " prodNames   ");
            //console.log(prodLen, "  prodLen  ")
            // console.log(fullCommand, " finalStr ")
            cb(null, fullCommand);
         }
      })
   }

   // Creating the batFile
   function crtBatFile(fullCommand, cb) {
      let batFile = (osType !== "Linux") ? "run_act.bat" : "run_act.sh";
      let file = path.join(results, batFile)
      fs.writeFile(file, fullCommand, (err) => {
         if (err) {
            cb(err);
         } else {
            cb(null, file)
         }
      })

   }

   // Running the batFile
   function runBatFile(file, cb) {
      const {
         exec,
         execFile
      } = require('child_process');
      let args = [],
         options = {};
      var tmpPath = "cd " + path.join(__dirname, `../`);
      var tmpRunCommand = "bash " + file;
      console.log("========= " + tmpPath + "    " + tmpRunCommand);
      //execFile(file, args, options, (err, stdout, stderr) => {
      exec(`${tmpPath}; ${tmpRunCommand}`, (err, stdout, stderr) => {
         if (err) {
            console.log("error >>>>>>>>>", err);
            console.log("StdErr >>>>>>>>>>>>", stderr);
            cb(err)
         } else {
            console.log(stdout);
            cb(null)
         }
      });
   }
}