let neDB = require('nedb');
let path = require('path');

const db = {
    prjDb : new neDB({ filename: (path.join(__dirname ,'projects.db')), autoload: true }),
    schdlDb : new neDB({ filename: (path.join(__dirname ,'schedules.db')), autoload: true }),   
    userDb :new neDB({ filename: (path.join(__dirname ,'users.db')), autoload: true }),
    engineDb : new neDB({filename:(path.join(__dirname ,'engines.db')),autoload:true})
  };
  module.exports = db;