const Excel = require("exceljs");
const async = require("async");
const fs = require("fs")
const path = require("path");
const uniqId = require("uniqid");


// Writing the Transaction Matrix to the copied XL File
exports.writeToXL = (paths, sheetName, hexFlag) => {
   let {
      results,
      transMat,
   } = paths;
   const workbook = new Excel.Workbook();
   return new Promise((resolve, reject) => {
      async.waterfall([
            getCopiedFilename,
            getProductNames,
            getAttributeNames,
            getLastRow,
            getJSONData,
            prepareRows,
            rmDuplicateRows,
            createColumns,
            writeToTable,
            highlightNegative,
            writeToXLSheet
         ],
         (err) => {
            if (err) {
               reject(err);

            } else {
               resolve(true)
            }
         })
   })

   // Function to get the copied Filename
   function getCopiedFilename(callBack) {
      if (fs.existsSync(results)) {
         let filename = path.join(results, "results.xlsx");
         callBack(null, filename)
      } else {
         callBack(new Error("Results folder doesn't exixt"))
      }
   }

   // Function to get the product names from the products.json
   function getProductNames(filename, callBack) {
      let prodPath = path.join(transMat, sheetName, "tMtrxProdName.json")
      fs.readFile(prodPath, "utf-8", (err, prodName) => {
         if (err)
            callBack(err)
         else {
            let productNames = JSON.parse(prodName);
            // console.log(productNames, " prodName ", typeof (productNames))
            callBack(null, filename, productNames)
         }
      })
   }

   // Function to get the attribute names from the attribute.json
   function getAttributeNames(filename, productNames, callBack) {
      let attrPath = path.join(transMat, sheetName, "tMtrxUniqueAttr.json");
      fs.readFile(attrPath, "utf-8", (err, attrName) => {
         if (err)
            callBack(err)
         else {
            // console.log(attrNames, " attrName ")
            let parseAttr = JSON.parse(attrName);
            let attrNames = parseAttr.map((name) => {
               let val = `${name.charAt(0).toUpperCase()}${name.substring(1)}`.trim();
               return val;
            })
            callBack(null, filename, productNames, attrNames)
         }

      })

   }

   // Function to get the Last Row based on tags
   function getLastRow(filename, productNames, attrNames, callBack) {
      let tranTags = {};
      workbook.xlsx.readFile(filename)
         .then(() => {
            let ws = workbook.getWorksheet(sheetName);
            ws.eachRow((row, rowNumber) => {
               row.eachCell((cell) => {
                  if (cell.value === "#txn-start") {
                     tranTags.lastRowNo = rowNumber;
                     tranTags.actualRowCount = ws.actualRowCount;
                     tranTags.productNames = productNames;
                     tranTags.attrNames = attrNames;
                     tranTags.filename = filename;
                  }
               })
            })
            callBack(null, tranTags, ws);
         })
         .catch((err) => {
            // console.log(err, " get Last Row Catch Block");
            callBack(err)
         })

   }

   // Function to get the products JSON Data
   function getJSONData(tranTags, ws, callBack) {
      let jsonPath = path.join(transMat, sheetName, "tMtrxOutput.json")
      fs.readFile(jsonPath, "UTF-8", (err, jsonData) => {
         if (err) {
            callBack(err)
         } else {
            let JsonFileData = JSON.parse(jsonData);
            callBack(null, tranTags, JsonFileData, ws)
         }
      })

   }

   // Function to prepare the rows by filling the missing values for the attribute keys
   function prepareRows(tranTags, JsonFileData, ws, callBack) {
      let {
         productNames,
         attrNames
      } = tranTags;
      let records = [];
      let positiveRec = [];
      let negativeRec = [];
      let jsonDataLen = JsonFileData.length;
      let attrKeys = Object.keys(attrNames);
      let keys = attrKeys.map((el, index) => {
         return el = `_${index}`;
      });
      for (let i = 0; i < jsonDataLen; i++) {
         for (let j = 0; j < JsonFileData[i].length; j++) {
            let row = JsonFileData[i][j]
            let values = Object.values(row)
            for (let k = 0; k < keys.length; k++) {
               if (row.hasOwnProperty(keys[k]) === false) {
                  values.splice(k, 0, "NA")
               }
            }
            let slicedVal = values.slice(0, keys.length);
            let refinedVal = slicedVal.map((el) => {
               let val = ``;
               if (el.includes("_[[")) {
                  el = el.split("_[[")[0];
               }

               if (hexFlag === true) {
                  if ((el !== "NA") && (el.startsWith("[[N]]_") === false)) {
                     val = Buffer.from(el, "hex").toString("utf8")
                  } else {
                     val = el;
                  }
               } else {
                  val = el;

               }
               return val;
            })

            if (row.type === "Positive") {
               let positiveArr = [row.type, productNames[i], ...refinedVal];
               positiveRec.push(positiveArr)
            } else {
               let negativeArr = [row.type, productNames[i], ...refinedVal];
               negativeRec.push(negativeArr)
            }

         }
      }

      records.push(...positiveRec);
      records.push(...negativeRec);
      // console.log(records.length, " total length")
      // console.log(positiveRec.length, " total positiveRec length")
      // console.log(negativeRec.length, " total negativeRec length")
      callBack(null, tranTags, records, attrNames, ws)
   }

   // Function to remove the duplicate rows
   function rmDuplicateRows(tranTags, records, attrNames, ws, callBack) {
      let uniqueRecords = Array.from(new Set(records.map(JSON.stringify)), JSON.parse);
      let rows = uniqueRecords.map((rcrd, indx) => {
         let rcrdVal = Object.values(rcrd);
         rcrdVal.splice(0, 0, indx + 1)
         return rcrdVal;

      })
      callBack(null, tranTags, rows, attrNames, ws)
   }

   // Function to create the columns for transaction matrix along with style
   function createColumns(tranTags, rows, attrNames, ws, callBack) {
      let columnStyle = {
         font: {
            name: "Calibri",
            size: 10
         },
         width: 20
      };
      let columnArr = ["Test Condition ID", "Test Type", "Product", ...attrNames, "Interface", "Services", "Batch Type", "Alerts", "Reports", "Validation", "Expected Results", "BR", "IR"]
      let columns = columnArr.map((key, index) => {
         let val;
         if (index !== 0) {
            val = {
               "name": key,
               filterButton: true,
               "style": columnStyle
            }
         } else {
            val = {
               "name": key,
               style: columnStyle
            }
         }
         return val;
      })
      callBack(null, tranTags, rows, columns, ws)
   }

   // Function to write the transaction matrix as Table
   function writeToTable(tranTags, rows, columns, ws, callBack) {
      let {
         lastRowNo
      } = tranTags;
      let ref = `B${Number(lastRowNo + 3)}`;
      const headingRow = `B${Number(lastRowNo + 2)}`;
      let headStyle = {
         font: {
            size: 11,
            bold: true
         }
      }
      // ws.unprotect();
      ws.getCell(headingRow).value = `${sheetName} Matrix`;
      ws.getCell(headingRow).style = headStyle;
      ws.addTable({
         name: `${uniqId.time()}`,
         ref: ref,
         headerRow: true,
         // style: {
         //     font: {
         //         name: 'Calibri',
         //         size: 11,
         //         weight: true
         //     }
         // },
         columns: columns,
         rows: rows,
      });
      callBack(null, tranTags, ws)

   }

   // Function to highlight the negative values with red colour
   function highlightNegative(tranTags, ws, callBack) {
      ws.eachRow((row) => {
         row.eachCell((cell) => {
            let val = cell.value;
            if (typeof (val) === "string") {
               if (val.startsWith("[[N]]_")) {
                  let replacedVal = val.replace("[[N]]_", ""); //.split("_[[")[0];
                  cell.value = hexFlag === true ? Buffer.from(replacedVal, "hex").toString("utf8") : replacedVal;
                  cell.style = {
                     font: {
                        color: {
                           argb: "00FF0000"
                        }
                     }
                  }
               } else
                  cell.value = val;
            }
         })
      })
      callBack(null, tranTags)
   }

   // Function to write to XL sheet
   function writeToXLSheet(tranTags, callBack) {
      let {
         filename
      } = tranTags;
      workbook.xlsx.writeFile(filename).then(() => {
            callBack(null);
         })
         .catch((e) => {
            // console.log(e, " writing to the XL file error ");
            callBack(e)
         })
   }

}