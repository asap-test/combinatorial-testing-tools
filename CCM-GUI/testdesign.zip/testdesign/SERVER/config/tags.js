exports.tags = {
   "transTags": ["#at-start", "#values", "#test-methodology", "#prod-start", "#prod-end", "Test Methodology", "#at-end", "#txn-start"],
   "cnstrntTags": ["#constraint-product-start", "#constraint-attr", "#constraint-value", "#dep-atr", "#operator", "#dep-val-start", "#dep-val-end", "#constraint-product-end"],
   "intrFcTags": ["#intr-strt", "#intr-atr-strt", "#intr-atr-end", "#intr-end"],
   "icnstrntTags": ["#constraint-identifier", "#constraint-product-start", "#constraint-attr", "#constraint-value", "#dep-atr", "#operator", "#dep-val-start", "#dep-val-end", "#constraint-product-end"],
   "intrFcCol": ["Interface", "InterfaceID", "Source", "Destination", "Mode", "Middleware", "Transactions", "Attributes"]
}