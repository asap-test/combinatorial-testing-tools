module.exports = {
    'secret': 'MySuperSecretPassword',
    'cryptokey': 'A8t6yu890GHDGFULOdsb4ety'
  };