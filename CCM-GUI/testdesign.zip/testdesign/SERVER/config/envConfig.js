module.exports = {
  "runPath": "/var/www/ACCEL-TB-STANDALONE/_RUNS",
  // "runPath": "C:/Users/sathishkumarse/Documents/_RUNS"
};
