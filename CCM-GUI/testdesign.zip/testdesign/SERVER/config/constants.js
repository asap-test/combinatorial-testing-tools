exports.constants = {
    "engineId": "5f265dd66b20f8351a4d8fa6",
    "apiKey": "123-333-4444-55555-6666",
    "host": "http://localhost:4015",
    "hexConversion": true
}