const createError = require('http-errors'),
  express = require('express'),
  path = require('path'),
  cookieParser = require('cookie-parser'),
  logger = require('morgan'),
  mongoose = require('mongoose'),
  fs = require('fs'),
  http = require('http'),
  cors = require('cors'), // Cross Orgin
  app = express();

fs.exists('uploads', (exist) => {
  if (!exist) {
    fs.mkdirSync('uploads');
  }
})

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

// app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(cors());

//Route setup:
const indexRouter = require('./routes/index');
const scheduleRouter = require('./routes/api/schedule');
const extScheduleRouter = require('./routes/api/engSchedule');
const projectRouter = require('./routes/api/project');
const authRouter = require('./routes/api/authenticate');

//API setup:
app.use('/', indexRouter);
app.use('/api/schedule', scheduleRouter);
app.use('/api/engine/schedule', extScheduleRouter);
app.use('/api/project', projectRouter);
app.use('/api/authenticate', authRouter);


/// error handlers

/// catch 404 and forward to error handler
app.use(function (req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// development & Production error handler

if (process.env.ENV === 'development') {
  // will print stacktrace
  app.use(function (err, req, res, next) {
    console.log(err.stack);
    res.status(err.status || 500);
    res.json({
      'errors': {
        message: err.message,
        error: err
      }
    });
  });
  // } else if (process.env.ENV === 'production') {
} else {
  // production error handler
  // no stacktraces leaked to user
  app.use(function (err, req, res, next) {
    res.status(err.status || 500);
    res.json({
      'errors': {
        message: err.message,
        error: {}
      }
    });
  });
}

/**
 * Create HTTP server.
 */
// Assigning port
var server = http.createServer(app);
if (process.env.ENV === 'development') {
  server.listen(5010);
} else {
  server.listen(4015);
}

server.on('error', onError);
server.on('listening', onListening);

function onError(error) {
  console.log('Server Error' + error);
}

function onListening() {
  // Displaying Port and Enviornment in console
  console.log('APP Started in PORT: ' + server.address().port)
  require('./index').runScheduleId();
}


module.exports = app;
